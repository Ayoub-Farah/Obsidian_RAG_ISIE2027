source {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/scripts/ptp_hw.tcl}
open_hw_manager
connect_hw_server
set ptp_hw::targets {OBS001A OBS003A OBS002A}
set ptp_hw::ltx {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/build/ptp_capacity_search/k3_route/obsidian_ptp.ltx}
ptp_hw::collect OBS003A {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/reports/ptp_scope_4ppm_dsox3014t_20261030/provenance/B_lock_diagnostic/B_page_0.json}
ptp_hw::collect OBS003A {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/reports/ptp_scope_4ppm_dsox3014t_20261030/provenance/B_lock_diagnostic/B_page_1.json}
ptp_hw::collect OBS003A {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/reports/ptp_scope_4ppm_dsox3014t_20261030/provenance/B_lock_diagnostic/B_page_2.json}
close_hw_manager
puts PTP_B_DIAGNOSTIC_COMPLETE
