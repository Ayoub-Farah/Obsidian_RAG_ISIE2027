open_hw_manager
connect_hw_server
refresh_hw_server
puts "PTP_DISCOVERY_BEGIN"
foreach target [get_hw_targets] {puts "PTP_TARGET $target"}
puts "PTP_DISCOVERY_END"
close_hw_manager
