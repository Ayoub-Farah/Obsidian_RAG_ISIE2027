# Qualification PTP selon le nombre de sauts — DSOX3014T

**État : campagne partielle.**
Configuration K=3/N=9, run_id=10, `config_id=fe302fe061778994`.
Trois FPGA A/B/C, trois modules par carte ; neuf accumulateurs logiques avec un tirage fixe uniforme ±4 ppm.
CH1 reste sur TEST_SYNC de A/M1 ; CH3 mesure successivement les sorties OBS de A, B puis C.
Période logique 100 µs, maintenance 1 ms. Les identités OBS sont vérifiées par désactivation/réactivation.

![Résultats selon les sauts](distance_offset_jitter.png)

| Module | FPGA | Sauts h | Frontières physiques | Dérive (ppm) | N valides | Moyenne corrigée (ns) | SD (ns) | RMS corrigé (ns) | Max. absolu observé (ns) |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| M1 | A | 0 | 0 | +0.467 | 200 | -0.110 | 0.195 | 0.223 | 0.325 |
| M2 | A | 1 | 0 | -2.200 | 200 | 1.263 | 4.484 | 4.648 | 16.170 |
| M3 | A | 2 | 0 | +0.589 | 200 | 1.086 | 4.235 | 4.362 | 16.170 |

Le délai signé vaut front OBS moins front REF. Une valeur négative indique un front observé en avance.
La moyenne corrigée retire uniquement le biais commun des voies et sondes ; les différences de sorties FPGA et de pistes restent incluses.
SD utilise n−1 et ne comprend pas le biais ; RMS comprend le biais. Les statistiques proviennent des acquisitions SINGLE neuves, une valeur par acquisition.

Calibration sur le même net TEST_SYNC de A : biais moyen CH3−CH1 = **+0.059 ns**. Aucune variance de calibration n’est soustraite.

## Données et traçabilité

- [Tableau par saut, quantiles et dépassements](distance_measurements.csv).
- [Qualification détaillée](distance_qualification.json) et [analyse des acquisitions](analysis.json).
- [Programmation et configuration des trois cartes](provenance/programming.json).
- [Calibration des voies et sondes](provenance/calibration_result.json).
- [Événements d’état PTP conservés](provenance/health_events.json). Les points entourés en rouge ont un contrôle JTAG associé non nominal ; leurs formes d’onde restent visibles dans les résultats.
- Les fichiers `single_*.npz` et leurs préambules JSON conservent les octets CH1/CH3 et les origines temporelles distinctes fournies par l’instrument.
- Les captures larges `wide_before` vérifient la période ; elles sont exclues des statistiques fines.

## Portée des résultats

Les sauts suivent M1 → M2 → … → M9 : h=0..8, avec une frontière FPGA à M4 puis M7. Ce sont des résultats pour cette topologie et ce tirage de fréquences ; ils ne séparent pas à eux seuls l’effet du saut, de la fréquence et du chemin physique.
Les lectures JTAG avant/après sont ponctuelles. Les sélections successives ne mesurent pas simultanément tous les modules et ne prouvent pas l’absence de pulses perdus pendant les temps morts USB.
Les maxima et quantiles sont empiriques. Les fractions au-delà de 20/50/64 ns sont descriptives ; aucun critère d’acceptation n’a été imposé par l’utilisateur.
Le DSOX3014T est utilisé en acquisition normale, sans moyennage ni correction temporelle de sonde. L’instrument exporte la fenêtre RAW visible à son pas ADC natif ; celle-ci peut être plus petite que la mémoire d’acquisition interne. Les origines temporelles propres aux voies sont conservées.
La cadence effectivement relue et chaque préambule sont archivés. L’interpolation des fronts ne démontre pas une exactitude absolue à la picoseconde.

La première tentative de calibration `02_A_same_sync` est exclue : elle a été interrompue après 126 paires valides par une capture CH3 plate, CH1 restant active ; cause indéterminée. La série complète suivante contient 200 captures valides. Les essais de mise au point et le timeout d’armement `04_A_identity_reenabled` sont conservés comme diagnostics.

[Guide de programmation officiel Keysight 3000T](https://www.keysight.com/us/en/assets/9023-40024/miscellaneous/3kT_X-Series_prog_guide.pdf) : transfert BYTE, axes temporels par voie et acquisition DIGitize.

Reproduction offline :

```powershell
py -3 scripts/report_ptp_scope_distance.py "reports/ptp_scope_4ppm_dsox3014t_20261030" --config config/ptp_emulation_9_uniform_4ppm.json
```

Points incomplets : M3: incomplete waveform/health/wiring evidence; Missing modules: M4, M5, M6, M7, M8, M9.
