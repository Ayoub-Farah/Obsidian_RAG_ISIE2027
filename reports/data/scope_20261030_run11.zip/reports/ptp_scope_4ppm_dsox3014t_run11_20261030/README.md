# Qualification PTP selon le nombre de sauts — DSOX3014T

**État : acquisitions complètes, avec événements d’état PTP à qualifier.**
Configuration K=3/N=9, run_id=11, `config_id=16c87b5a422b4f71`.
Trois FPGA A/B/C, trois modules par carte ; neuf accumulateurs logiques avec un tirage fixe uniforme ±4 ppm.
CH1 reste sur TEST_SYNC de A/M1 ; CH3 mesure successivement les sorties OBS de A, B puis C.
Période logique 100 µs, maintenance 1 ms. La sélection MOSI est relue par JTAG ; le branchement est confirmé par l’opérateur.

![Résultats selon les sauts](distance_offset_jitter.png)

| Module | FPGA | Sauts h | Frontières physiques | Dérive (ppm) | N valides | Moyenne OBS−REF (ns) | SD (ns) | RMS (ns) | Max. absolu observé (ns) |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| M1 | A | 0 | 0 | +0.467 | 1000 | -0.186 | 0.075 | 0.201 | 0.457 |
| M2 | A | 1 | 0 | -2.200 | 1000 | 2.113 | 5.629 | 6.010 | 16.246 |
| M3 | A | 2 | 0 | +0.589 | 1000 | 2.212 | 5.721 | 6.131 | 16.246 |
| M4 | B | 3 | 1 | -1.266 | 200 | -4.148 | 5.135 | 6.591 | 24.229 |
| M5 | B | 4 | 1 | +3.090 | 200 | -3.370 | 5.865 | 6.752 | 27.560 |
| M6 | B | 5 | 1 | -0.627 | 200 | -7.442 | 7.028 | 10.224 | 24.913 |
| M7 | C | 6 | 2 | -3.694 | 200 | 4.454 | 7.973 | 9.115 | 12.171 |
| M8 | C | 7 | 2 | +2.011 | 200 | 7.519 | 8.959 | 11.679 | 17.618 |
| M9 | C | 8 | 2 | +2.498 | 200 | 5.275 | 7.799 | 9.400 | 13.314 |

Le délai signé vaut front OBS moins front REF. Une valeur négative indique un front observé en avance.
**Mesures brutes sans calibration des sondes, conformément au choix de l’opérateur.** Les décalages des voies, sondes et pistes sont inclus ; aucun biais d’un essai précédent n’est soustrait.
SD utilise n−1 ; RMS comprend le décalage moyen. Une valeur par enregistrement déclenché. Les segments d’une rafale peuvent être corrélés.


## Données et traçabilité

- [Tableau par saut, quantiles et dépassements](distance_measurements.csv).
- [Qualification détaillée](distance_qualification.json) et [analyse des acquisitions](analysis.json).
- [Programmation et configuration des trois cartes](provenance/programming.json).
- [Événements d’état PTP conservés](provenance/health_events.json). Les points entourés en rouge ont un contrôle JTAG associé non nominal ; leurs formes d’onde restent visibles dans les résultats.
- Les fichiers `single_*.npz` et leurs préambules JSON conservent les octets CH1/CH3 et les origines temporelles distinctes fournies par l’instrument.
- Les captures larges `wide_before` vérifient la période ; elles sont exclues des statistiques fines.
- En mode segmenté, les horodatages UTC des fichiers sont ceux de leur export. Les étiquettes relatives `segment_time_tag_s` et les rafales sont conservées ; 200 fronts successifs couvrent environ 20 ms.

## Portée des résultats

Les sauts suivent M1 → M2 → … → M9 : h=0..8, avec une frontière FPGA à M4 puis M7. Ce sont des résultats pour cette topologie et ce tirage de fréquences ; ils ne séparent pas à eux seuls l’effet du saut, de la fréquence et du chemin physique.
Les lectures JTAG avant/après sont ponctuelles. Les sélections successives ne mesurent pas simultanément tous les modules et ne prouvent pas l’absence de pulses perdus pendant les temps morts USB.
Les maxima et quantiles sont empiriques. Les fractions au-delà de 20/50/64 ns sont descriptives ; aucun critère d’acceptation n’a été imposé par l’utilisateur.
Le DSOX3014T est utilisé en acquisition normale, sans moyennage ni correction temporelle de sonde. L’instrument exporte la fenêtre RAW visible à son pas ADC natif ; celle-ci peut être plus petite que la mémoire d’acquisition interne. Les origines temporelles propres aux voies sont conservées.
La cadence effectivement relue et chaque préambule sont archivés. L’interpolation des fronts ne démontre pas une exactitude absolue à la picoseconde.

[Guide de programmation officiel Keysight 3000T](https://www.keysight.com/us/en/assets/9023-40024/miscellaneous/3kT_X-Series_prog_guide.pdf) : transfert BYTE, axes temporels par voie et acquisition DIGitize.

Reproduction offline :

```powershell
py -3 scripts/report_ptp_scope_distance.py "reports/ptp_scope_4ppm_dsox3014t_run11_20261030" --config "config/ptp_emulation_9_uniform_4ppm_run11.json" --allow-uncalibrated
```

Événement JTAG before B_M4 : carte `OBS003A`, `all_local_locked=False`, `operational=True`. Le statut agrégé ne permet pas d’identifier le module concerné ni la durée du déverrouillage.
Écarts aux contrôles : M4: non-nominal health snapshot; waveform dataset is complete.
