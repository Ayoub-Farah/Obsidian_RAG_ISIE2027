source {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/scripts/ptp_hw.tcl}
set ptp_hw::targets {OBS001A OBS003A OBS002A}
set ptp_hw::ltx {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/build/ptp_capacity_search/k3_route/obsidian_ptp.ltx}
set ptp_program_bit {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/build/ptp_capacity_search/k3_route/obsidian_ptp.bit}
open_hw_manager
connect_hw_server
refresh_hw_server
foreach ptp_program_serial $ptp_hw::targets {
 set ptp_program_targets [get_hw_targets */$ptp_program_serial]
 if {[llength $ptp_program_targets]!=1} {error "Expected one cable $ptp_program_serial"}
 open_hw_target [lindex $ptp_program_targets 0]
 set ptp_program_devices [get_hw_devices -of_objects [current_hw_target]]
 if {[llength $ptp_program_devices]!=1 || [get_property PART [lindex $ptp_program_devices 0]] ne "xc7a35t"} {error "Unexpected FPGA on $ptp_program_serial"}
 puts "PTP_PREFLIGHT_OK $ptp_program_serial"
 close_hw_target
}
foreach ptp_program_serial $ptp_hw::targets {
 open_hw_target [lindex [get_hw_targets */$ptp_program_serial] 0]
 set ptp_program_device [lindex [get_hw_devices -of_objects [current_hw_target]] 0]
 set_property PROGRAM.FILE $ptp_program_bit $ptp_program_device
 set_property PROBES.FILE $ptp_hw::ltx $ptp_program_device
 puts "PTP_PROGRAM_BEGIN $ptp_program_serial";flush stdout
 program_hw_devices $ptp_program_device
 puts "PTP_BIT_LOADED $ptp_program_serial";flush stdout
 refresh_hw_device $ptp_program_device
 set ptp_program_vios [get_hw_vios -of_objects $ptp_program_device]
 if {[llength $ptp_program_vios]!=1} {error "Expected one PTP VIO after loading $ptp_program_serial"}
 set ptp_program_vio [lindex $ptp_program_vios 0]
 refresh_hw_vio $ptp_program_vio
 set ptp_program_status [expr 0x[obsidian_hw::read_input $ptp_program_vio 0]]
 if {($ptp_program_status>>232)!=0x505401 || (($ptp_program_status>>16)&65535)!=3} {error "Unexpected PTP signature/capacity on $ptp_program_serial"}
 obsidian_hw::write_output $ptp_program_vio 0 1
 puts "PTP_PROGRAM_COMPLETE $ptp_program_serial";flush stdout
 close_hw_target
}
foreach ptp_program_serial {OBS003A OBS002A OBS001A} {
 set ptp_program_vio [ptp_hw::select $ptp_program_serial]
 obsidian_hw::write_output $ptp_program_vio 0 0
 close_hw_target
}
after 200
foreach ptp_program_serial $ptp_hw::targets {
 set ptp_program_vio [ptp_hw::select $ptp_program_serial]
 refresh_hw_vio $ptp_program_vio
 set ptp_program_status [expr 0x[obsidian_hw::read_input $ptp_program_vio 0]]
 if {!($ptp_program_status&4) || ($ptp_program_status&3)} {error "Expected unconfigured idle PTP image on $ptp_program_serial"}
 puts "PTP_PROGRAMMED_IDLE $ptp_program_serial [format %064llx $ptp_program_status]"
 puts "PTP_BOOT_LINKS $ptp_program_serial [obsidian_hw::read_input $ptp_program_vio 4]"
 close_hw_target
}
close_hw_manager
puts "PTP_ALL_THREE_PROGRAMMED";flush stdout

source {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/scripts/ptp_hw.tcl}
open_hw_manager
connect_hw_server
set ptp_hw::targets {OBS001A OBS003A OBS002A}
set ptp_hw::ltx {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/build/ptp_capacity_search/k3_route/obsidian_ptp.ltx}
set ptp_hw::timeout_ms 300000
ptp_hw::stop_all
ptp_hw::stage OBS001A 0 {0000000000000009 0000000a0000186a 00000007a1200000 0000000000000040 16c87b5a422b4f71 000000000000000b 0000f424013528a6 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 00000001000007d5 0000000000000000 0000000000010001 0000000000000000 00000000ffffdb18 0000000000000000 0000000000010001 0000000000000000 00000001000009e1 0000000000000000 0000000000010001 0000000000000000} 3
ptp_hw::stage OBS003A 1 {0000000000000009 0000000a0000186a 00000007a1200000 0000000000000040 16c87b5a422b4f71 000000000000000b 0000f424013528a7 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 00000000ffffeac3 0000000000000000 0000000000010001 0000000000000000 00000001000033d7 0000000000000000 0000000000010001 0000000000000000 00000000fffff57c 0000000000000000 0000000000010001 0000000000000000} 3
ptp_hw::stage OBS002A 2 {0000000000000009 0000000a0000186a 00000007a1200000 0000000000000040 16c87b5a422b4f71 000000000000000b 0000f424013528a8 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 0000000000000000 00000000ffffc207 0000000000000000 0000000000010001 0000000000000000 00000001000021bd 0000000000000000 0000000000010001 0000000000000000 00000001000029e8 0000000000000000 0000000000010001 0000000000000000} 3
ptp_hw::pulse OBS003A 4
ptp_hw::pulse OBS002A 4
ptp_hw::pulse OBS001A 4
ptp_hw::check_active 16c87b5a422b4f71 9 3
ptp_hw::observe OBS002A 8
ptp_hw::pulse OBS001A 5
ptp_hw::wait_running 0
close_hw_manager
puts "PTP_COMMAND_COMPLETE"

source {C:/Users/afarahhass/Documents/Xilinx_project/Obsidian_RAG/reports/ptp_scope_4ppm_dsox3014t_run11_20261030/hardware_worker.tcl}
