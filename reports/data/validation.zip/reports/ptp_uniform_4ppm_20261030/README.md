# Neuf horloges logiques avec dérives uniformes ±4 ppm

La configuration [K=3/N=9, run_id=10](../../config/ptp_emulation_9_uniform_4ppm.json)
attribue une fréquence logique propre à chaque module, y compris aux trois
modules d'un même FPGA. Son `config_id` est `fe302fe061778994`.
Les trois oscillateurs physiques alimentent les neuf accumulateurs Q48.32
indépendants déjà présents dans l'image K=3. Aucun changement du RTL synthétisé
ni nouveau bitstream n'est nécessaire pour cette injection.

## Loi et réalisation retenues

Chaque dérive est tirée une seule fois avec `random.Random(20261030).randint(-4000, 4000)` :
loi uniforme discrète en ppb, bornes incluses, tirages indépendants par
identifiant global. Les valeurs restent constantes pendant les acquisitions
et les changements de sélection OBS. On ne recentre pas le tirage et on ne
force pas les extrêmes. Deux valeurs égales restent possibles avec cette loi ;
les neuf valeurs de cette réalisation sont distinctes.

| Module | ID global RTL | FPGA | Index local | Dérive injectée (ppm) | Écart injecté à M1 (ppm) |
|---|---:|---|---:|---:|---:|
| M1 | 0 | A | 0 | +0,467 | 0,000 |
| M2 | 1 | A | 1 | −2,200 | −2,667 |
| M3 | 2 | A | 2 | +0,589 | +0,122 |
| M4 | 3 | B | 0 | −1,266 | −1,733 |
| M5 | 4 | B | 1 | +3,090 | +2,623 |
| M6 | 5 | B | 2 | −0,627 | −1,094 |
| M7 | 6 | C | 0 | −3,694 | −4,161 |
| M8 | 7 | C | 1 | +2,011 | +1,544 |
| M9 | 8 | C | 2 | +2,498 | +2,031 |

L'hôte calcule pour chaque module :

```text
step_i = 2^32 + trunc(drift_ppb[i] × 2^32 / 10^9)
```

Chaque accumulateur avance de `step_i` à chaque cycle physique. Le transport
PTP reste en Q48.16 et les fronts GPIO sur la grille physique de 16 ns. La
troncature du pas introduit moins de 0,233 ppb d'écart à la dérive demandée.
Les dérives physiques des cartes s'ajoutent à l'injection logique.

Les autres paramètres reprennent l'essai du 29 octobre : période logique
100 µs, maintenance toutes les 1 ms, offsets initiaux nuls, aucun jitter ni
perte injectés, un tick par direction dans les injecteurs de liens. Le servo
PTP corrige les offsets ; il ne corrige pas la fréquence de ces accumulateurs.

## Reproduction et application

Le générateur copie les paramètres de base et remplace uniquement `seed`,
`run_id` et `drift_ppb`. Il refuse d'écraser un fichier existant :

```powershell
py -3 scripts/generate_ptp_clock_config.py --config config/ptp_emulation_9.example.json --seed 20261030 --run-id 10 --output captures/ptp_uniform_4ppm_reproduction.json
```

La préparation Tcl a été exécutée sans connexion au matériel :

```powershell
py -3 scripts/run_ptp_campaign.py run --config config/ptp_emulation_9_uniform_4ppm.json --image-dir build/ptp_capacity_search/k3_route --node 9 --dry-run --output captures/ptp_uniform_4ppm_20261030_preview
```

Pour appliquer cette configuration à l'image K=3 déjà chargée sur les trois
cartes, avec A/B/C accessibles ensemble par JTAG :

```powershell
py -3 scripts/run_ptp_campaign.py run --config config/ptp_emulation_9_uniform_4ppm.json --image-dir build/ptp_capacity_search/k3_route --node 9 --output captures/ptp_uniform_4ppm_run10
```

Cette dernière commande effectue STOP/vidage, écrit et relit les registres,
COMMIT B/C/A, vérifie le hash, puis START sur A. Elle ne programme pas les FPGA.
**Elle n'a pas été exécutée dans cette préparation.** Aucune nouvelle mesure
oscilloscope n'est présentée ici. L'image routée K=3 a été contrôlée hors ligne :
empreintes BIT/LTX et sources RTL conformes au build validé.

## Validation reproductible

**34 tests Python et les quatre cas RTL ont passé.** Les deux scénarios à
±4 ppm ont chacun produit 144 points valides (16 par module), sans holdover ni
erreur aux instants échantillonnés. Chaque suiveur a continué sa maintenance.

```powershell
py -3 -m unittest sim.test_ptp_clock_config sim.test_ptp_emulation sim.test_ptp_hw sim.test_ptp_capacity_analysis sim.test_ptp_validation -v
py -3 scripts/run_vivado_tests.py --only 'tb_ptp_chain_(uniform_4ppm|4ppm_extremes|3|phased)' --output-dir build/ptp_uniform_4ppm_validation_20261030
```

Les tests Python vérifient le tirage reproductible, la conservation des autres
paramètres, M1 inclus, les bornes, le passage ID global → carte/index local →
registre de pas, y compris une population inégale, et les extrêmes ±4000 ppb.

Le cas RTL `uniform_4ppm` lit les neuf valeurs du JSON via un fichier dont
l'empreinte est conservée par le runner. À chaque cycle observé, il soustrait
la correction PTP du temps logique et vérifie exactement l'avance
`floor(raw_board × step_i / 2^16)`. Il vérifie aussi le maintien du lock hors
holdover. Il exporte 16 échantillons simultanés des neuf modules, espacés de
1 ms après acquisition, avec les pas, les dérives et les erreurs vraies à M1.
Ce test porte sur le cœur RTL ; le chemin de programmation des registres est
vérifié séparément par les tests Python.

Le cas `4ppm_extremes` impose alternativement −4 et +4 ppm aux neuf modules,
avec les mêmes périodes. Les cas N=3 sans dérive et N=10 à phases décalées avec
±2 ppm contrôlent la conservation des scénarios existants.

Les résultats et empreintes de cette exécution sont dans
[`validation.json`](validation.json). Les CSV sont des **simulations RTL à
liens physiques modélisés**, pas des mesures des cartes ou de l'oscilloscope.
L'espacement de 1 ms sert au contrôle du maintien et échantillonne près de la
même phase de maintenance ; les dispersions de ces 16 points ne constituent
pas une caractérisation du jitter sur toute la période de maintenance.

## Effet attendu et comparaison au rapport précédent

La loi de fréquence est distincte d'une loi de jitter temporel : on ne tire
pas un nouveau décalage de phase à chaque tick ou acquisition. Entre deux
corrections, l'apport de dérive libre entre i et M1 s'écrit approximativement :

```text
variation de (temps_i − temps_M1), en ns
    = (drift_i − drift_M1), en ppm × durée, en ms
```

Deux tirages peuvent différer de 8 ppm, soit jusqu'à 8 ns supplémentaires
sur 1 ms de dérive libre. Ce calcul ne borne pas l'erreur PTP totale : délais
d'application des corrections, propagation dans la chaîne, quantification,
asymétries et oscillateurs physiques interviennent aussi. Pour les pulses
OBS−REF, une horloge en avance tend à donner un front en avance, donc le signe
est opposé à celui de l'erreur des temps à un instant commun.

La [campagne scope](../ptp_scope_20261029T160956Z/README.md) et le
[modèle de distance](../ptp_distance_model_20261029/MODELE.md) restent la base
sans injection de dérive logique. Le choix `virtual_sigma_ns=0` de ce modèle
ne décrit pas cette nouvelle dynamique. La distribution ±4 ppm ne permet pas
à elle seule de déduire un nouveau sigma résiduel ou de recalibrer les queues
rares observées sur le matériel. La comparaison quantitative demandera une
nouvelle campagne scope avec les mêmes réglages et ce `config_id` enregistré.
